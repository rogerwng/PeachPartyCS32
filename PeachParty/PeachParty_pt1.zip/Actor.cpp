#include "Actor.h"
#include "StudentWorld.h"

// Students:  Add code to this file, Actor.h, StudentWorld.h, and StudentWorld.cpp

//
// IMPLEMENTING ACTOR
//

// constructor
// takes same arguments as GraphObject constructor and uses these to initialize the base GraphObject
Actor::Actor(int imageID, int startX, int startY, StudentWorld* world) : GraphObject(imageID, startX, startY)
{
    // actors are alive when first constructed
    m_active = true;
    m_world = world;
}



//
// IMPLEMENTING AVATAR
//
Avatar::Avatar(int imageID, int startX, int startY, StudentWorld* world) : Actor(imageID, startX, startY, world)
{
    m_walkingDir = right;
    m_ticks_to_move = 0;
    m_squares_to_move = 0;
    m_state = STATE_WAITING;
}

Avatar::~Avatar() {}

// checks if the pixel that the avatar is moving to is part of a valid square
bool Avatar::canMove(int dir) const
{
    // coord of pixel that avatar moves to
    int x_new, y_new;
    getPositionInThisDirection(dir, 2, x_new, y_new);
    
    // convert coord to board axis
    x_new /= 16;
    y_new /= 16;
    
    int x = getX();
    int y = getY();
    
    switch (dir)
    {
        case up:
            if (y == VIEW_HEIGHT)
                return false;
            y += 16;
            break;
        case down:
            if (y == 0)
                return false;
            y -= 2;
            break;
        case left:
            if (x == 0)
                return false;
            x -= 2;
            break;
        case right:
            if (x == VIEW_WIDTH)
                return false;
            x += 16;
            break;
    }
    
    x /= SPRITE_WIDTH;
    y /= SPRITE_HEIGHT;
    
    Board::GridEntry ge = getWorld()->getBoard()->getContentsOf(x,y);
    
    if (ge == Board::empty)
        return false;
    
    return true;
}

void Avatar::setWalkingDir(int dir)
{
    m_walkingDir = dir;
    
    if (dir == left)
        setDirection(left);
    else
        setDirection(right);
}

void Avatar::availableUpDown()
{
    if (canMove(up))           // prioritizes up over down
        setWalkingDir(up);
    else if (canMove(down))
        setWalkingDir(down);
}

void Avatar::availableRightLeft()
{
    if (canMove(right))           // prioritizes right over left
        m_walkingDir = right;
    else if (canMove(left))
        m_walkingDir = left;
   //else
     //   if (m_walkingDir == up)
       //     setWalkingDir(down);
        //else
          //  setWalkingDir(up);
}

void Avatar::availableTurn()
{
    switch(m_walkingDir)
    {
        case right:
            availableUpDown();
            break;
        case left:
            availableUpDown();
            break;
        case up:
            availableRightLeft();
            break;
        case down:
            availableRightLeft();
            break;
    }
}



//
//IMPLEMENTING PLAYER AVATAR
//

// constructor
PlayerAvatar::PlayerAvatar(int imageID, int startX, int startY, int playerNum, StudentWorld* world) : Avatar(imageID, startX, startY, world)
{
    // initialize data members
    m_player = playerNum;
    m_coins = 0;
    m_stars = 0;
    m_vortex = false;
}

//destructor
PlayerAvatar::~PlayerAvatar()
{
}

void PlayerAvatar::swapCoins(PlayerAvatar& p0)
{
    int temp = this->m_coins;
    this->m_coins = p0.m_coins;
    p0.m_coins = temp;
}

void PlayerAvatar::swapStars(PlayerAvatar& p0)
{
    int temp = this->m_stars;
    this->m_stars = p0.m_stars;
    p0.m_stars = temp;
}

void PlayerAvatar::swapPosMov(PlayerAvatar& p0)
{
    // swap walking dir
    int temp = this->getWalkingDir();
    this->setWalkingDir(p0.getWalkingDir());
    p0.setWalkingDir(temp);
    
    // swap ticks to move
    temp = this->getTicksToMove();
    this->setTicksToMove(p0.getTicksToMove());
    p0.setTicksToMove(temp);
    
    // swap states
    temp = this->getState();
    this->setState(p0.getState());
    p0.setState(temp);
    
    // swap sprite direction: uses GraphObject func
    temp = this->getDirection();
    this->setDirection(p0.getDirection());
    p0.setDirection(temp);
}

// doSomething
void PlayerAvatar::doSomething()
{
    if (!isWalking())
    {
        int action = this->getWorld()->getAction(m_player);
        
        switch(action) {
            case ACTION_ROLL:
                setTicksToMove(randInt(1,10) * 8);
                setWalking();
                break;
            default:
                return;
        }
    }
    
    if (isWalking())
    {
        if (!canMove(getWalkingDir()))
        {
            availableTurn();
        }
        
        int x_new, y_new;
        getPositionInThisDirection(getWalkingDir(), 2, x_new, y_new);
        //moveForward(2);
        moveTo(x_new, y_new);
        setTicksToMove(getTicksToMove() - 1);
        if (getTicksToMove() == 0)
            setWaiting();
    }
}



//
// IMPLEMENTING SQUARE
//

CoinSquare::CoinSquare(int imageID, int startX, int startY, StudentWorld* world, int sign) : Actor(imageID, startX, startY, world)
{
    // whether or not Coin square is blue or red is passed to CoinSquare when it is constructed
    m_sign = sign;
}

CoinSquare::~CoinSquare()
{
    
}

void CoinSquare::doSomething()
{
    if (!this->isActive())
        return;
    
    
}

//
// IMPLEMENTING BLUE COIN
//

BlueCoin::BlueCoin(int imageID, int startX, int startY, StudentWorld* world) : CoinSquare(imageID, startX, startY, world, 1)
{}

BlueCoin::~BlueCoin() {}

//
// IMPLEMENTING RED COIN
//

RedCoin::RedCoin(int imageID, int startX, int startY, StudentWorld* world) : CoinSquare(imageID, startX, startY, world, -1)
{}

RedCoin::~RedCoin() {}
