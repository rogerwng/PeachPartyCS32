#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "Actor.h"
#include "GameWorld.h"
#include "Board.h"
#include <string>
#include <vector>

// Students:  Add code to this file, StudentWorld.cpp, Actor.h, and Actor.cpp

class StudentWorld : public GameWorld
{
public:
  StudentWorld(std::string assetPath);
    ~StudentWorld();
  virtual int init();
  virtual int move();
  virtual void cleanUp();
    
// accessors
    Board* getBoard() { return &bd; }

private:
    // loads board, returns 0 for loaded board, 1 for board not found, 2 for bad board
    void loadBoard(int board);
    // initializes actors after board loaded
    void initActors();
    
    // vector data structure holds all non-player actors in the world
    std::vector<Actor*> m_actors;
    // p1 -> peach
    PlayerAvatar* p1;
    // p2 -> yoshi
    PlayerAvatar* p2;
    
    Board bd;
    int m_bank;
};

#endif // STUDENTWORLD_H_
