#include "StudentWorld.h"
#include "GameConstants.h"
#include "Actor.h"
#include <sstream>
#include <string>
#include <iostream>
using namespace std;

GameWorld* createStudentWorld(string assetPath)
{
    return new StudentWorld(assetPath);
}

// Students:  Add code to this file, StudentWorld.h, Actor.h, and Actor.cpp

StudentWorld::StudentWorld(string assetPath)
: GameWorld(assetPath)
{
    m_bank = 0;
    
    //p1 = nullptr;
    //p2 = nullptr;
}

StudentWorld::~StudentWorld() {
    //delete p1;
    //cleanUp();
    
}

// loads board by, takes string of board file name
void StudentWorld::loadBoard(int board)
{
    ostringstream oss;
    oss << "board0" << board << ".txt";
    
    string board_file = assetPath() + oss.str();
    Board::LoadResult result = bd.loadBoard(board_file);
    
    if (result == Board::load_fail_file_not_found)
        cerr << "Board loaded: "  << board_file << "\n";
    else if (result == Board::load_fail_bad_format)
        cerr << "Board not found: " << board_file << "\n";
    else if (result == Board::load_success)
        cerr << "Board loaded: "  << board_file << "\n";
}

// initializes actors after board loaded
void StudentWorld::initActors()
{
    // loop through 16 x 16 board to initialize actors
    for (int x = 0; x < BOARD_WIDTH; x++)
    {
        for (int y = 0; y < BOARD_HEIGHT; y++)
        {
            Board::GridEntry ge = bd.getContentsOf(x, y);
            switch(ge)
            {
                case Board::empty:
                    break;
                case Board::boo:
                    break;
                case Board::bowser:
                    break;
                case Board::player:{
                    //PlayerAvatar *temp = new PlayerAvatar(IID_PEACH,x * SPRITE_WIDTH,y * SPRITE_HEIGHT,1,this);
                    p1 = new PlayerAvatar(IID_PEACH,x * SPRITE_WIDTH,y * SPRITE_HEIGHT,1,this);
                    p2 = new PlayerAvatar(IID_YOSHI,x * SPRITE_WIDTH,y * SPRITE_HEIGHT,2,this);
                    m_actors.push_back(new BlueCoin(IID_BLUE_COIN_SQUARE,x*SPRITE_WIDTH,y*SPRITE_HEIGHT,this));
                    break;}
                case Board::blue_coin_square:
                    m_actors.push_back(new BlueCoin(IID_BLUE_COIN_SQUARE,x*SPRITE_WIDTH,y*SPRITE_HEIGHT,this));
                    break;
                case Board::red_coin_square:
                    m_actors.push_back(new RedCoin(IID_RED_COIN_SQUARE,x*SPRITE_WIDTH,y*SPRITE_HEIGHT,this));
                    break;
                case Board::up_dir_square:
                    break;
                case Board::down_dir_square:
                    break;
                case Board::left_dir_square:
                    break;
                case Board::right_dir_square:
                    break;
                case Board::event_square:
                    break;
                case Board::bank_square:
                    break;
                case Board::star_square:
                    break;
            }
        }
    }
}

int StudentWorld::init()
{
    startCountdownTimer(99);  // this placeholder causes timeout after 5 seconds
    
    loadBoard(getBoardNumber());
    initActors();
    
    return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld::move()
{
    // This code is here merely to allow the game to build, run, and terminate after you hit ESC.
    // Notice that the return value GWSTATUS_NOT_IMPLEMENTED will cause our framework to end the game.
    
    // ask all actors to do smt
    if (p1->isActive())
        p1->doSomething();
    if (p2->isActive())
        p2->doSomething();
    
    for (size_t k = 0; k < m_actors.size(); k++)
    {
        if (m_actors[k]->isActive())
            m_actors[k]->doSomething();
    }

    setGameStatText("Game will end in a few seconds");
    
    if (timeRemaining() <= 0)
        return GWSTATUS_NOT_IMPLEMENTED;
    
    return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::cleanUp()
{
    delete p1;
    delete p2;
    for (size_t k = 0; k < m_actors.size(); k++)
        delete m_actors[k];
    m_actors.clear();
}
